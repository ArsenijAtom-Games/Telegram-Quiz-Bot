from aiogram import types, Dispatcher, Bot
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.utils import executor
import time
from base import add_user, get_user_from_id, check_admin, set_admin, add_question, delete_questions, get_question_from_id, get_questions_count, get_all_users, result, update_user_results

token = '8236018541:AAEhnjGkSobUZLt_meNcKKYTbnzZaiDkmb4'

bot = Bot(token = token)
dp = Dispatcher(bot, storage = MemoryStorage())

class BotStates(StatesGroup):
    wait_question = State()
    wait_answer = State()

start_quiz = False

async def start(message: types.Message):
    user = message.from_user

    if get_user_from_id(user.id):
        await message.answer("С возвращением! 👋")
    else:
        add_user(user.id)
        await message.answer("Добро пожаловать! 👋\n Вы зарегистрированы! 💾")

async def give_admin(message:types.Message):
    args = message.text.split(" ")
    if not check_admin(message.from_user.id):
        if len(args) == 2:
            if args[1] == "1234":
                set_admin(message.from_user.id)
                await message.answer("Вы получили права администратора ✅")
            else:
                await message.answer("Неверный пароль! 🚫")
        else:
            await message.answer("Неверное количество аргументов! 🚫")
    else:
        await message.answer("У вас уже есть права администратора! ✅")

async def reset_questions(message: types.Message):
    delete_questions()
    await message.answer('''Вопросы сброшены. Введите новые вопросы по одному в формате:\nВопрос\nОтвет 1\nОтвет 2\nОтвет 3\nОтвет 4\nПравильный ответ\nДля окончания ввода введите "Стоп"''')
    await BotStates.wait_question.set()

async def added_question(message: types.Message, state: FSMContext):
    if message.text.lower() == "стоп":
        await state.finish()
        await message.answer("Добавление вопросов закончилось ✅")
        return

    args = message.text.split(";")
    if len(args) == 6:
        args[5] = args[int(args[5])]
        add_question(*args)
        await message.answer("Вопрос добавлен!✅\n Спасибо!❤️")
    else:
        await message.answer("Нехватает параметров для добавления вопроса❗")

async def quiz(message: types.Message, state: FSMContext):
    question = get_question_from_id(1)
    count = get_questions_count()

    await state.update_data(correct_answers=0)
    await state.update_data(count=count)
    await state.update_data(current_number=1)
    await state.update_data(answer=question[-1])
    await state.update_data(begin_time=time.time())

    keyboard = types.ReplyKeyboardMarkup()
    for answer in question[2:6]:
        keyboard.add(answer)

    await message.answer(question[1], reply_markup=keyboard)
    await BotStates.wait_answer.set()

async def quiz_check_answer(message: types.Message, state: FSMContext):
    data = await state.get_data()

    if message.text.lower() == data["answer"].lower():
        await state.update_data(correct_answers=data["correct_answers"] + 1)
        await message.answer("Верно! ✅")
    else:
        await message.answer(F"Неверно ❌, правильный ответ {data['answer']}")

    if data["current_number"] == data["count"]:
        data = await state.get_data()
        total_time = int(time.time() - data['begin_time'])
        
        update_user_results(message.from_user.id, total_time, data['correct_answers'])

        await message.answer(f"Квиз закончен❗ 🔒\nВерных ответов: {data['correct_answers']}", reply_markup=types.ReplyKeyboardRemove())
        await state.finish()
    else:
        next_question_number = data['current_number'] + 1
        question = get_question_from_id(next_question_number)
        await state.update_data(current_number=next_question_number)
        await state.update_data(answer=question[-1])

        keyboard = types.ReplyKeyboardMarkup()
        for answer in question[2:6]:
            keyboard.add(answer)

        await message.answer(question[1], reply_markup=keyboard)

async def start_game(message: types.Message):
    users = get_all_users()
    global start_quiz
    if not check_admin(message.from_user.id):
        await message.answer("У вас нет прав администратора❗ 🚫")
    else:
        if start_quiz == True:
            await message.answer(f"Игра уже запущена")
        else:
            users = get_all_users()
            start_quiz = True
            await message.answer("Игра успешно запущена❗")
            for user in users:
                user_id = user[0]
                await bot.send_message(user_id, "Игра началась, приступайте❗")

async def stop_game(message:types.Message):
    if not check_admin(message.from_user.id):
        await message.answer("У вас нет прав администратора❗ 🚫")
    else:
        users = get_all_users()
        global start_quiz
        start_quiz = False
        for user in get_all_users():
            await bot.send_message(user[0], f"Игра остановлена❗ ⛔")

async def show_result(message:types.Message):
    results = result()
    response = "А вот и таблица рекордов:\n\n"
    for i, (user_id, time, correct) in enumerate(results, 1):
        response += f"{i}. ID: {user_id} - Правильных ответов: {correct}, Время: {time} секунд\n"
    await message.answer(response)

def register(dp: Dispatcher):
    dp.register_message_handler(start, commands="start")
    dp.register_message_handler(give_admin, commands = "admin")
    dp.register_message_handler(added_question, state=BotStates.wait_question)
    dp.register_message_handler(quiz_check_answer, state=BotStates.wait_answer)
    dp.register_message_handler(reset_questions, commands="questions")
    dp.register_message_handler(quiz, commands="quiz")
    dp.register_message_handler(start_game, commands="start_game")
    dp.register_message_handler(stop_game, commands="stop_game")
    dp.register_message_handler(show_result, commands="show_result")

register(dp)
executor.start_polling(dp, skip_updates=True)