import sqlite3
connection = sqlite3.connect("bot.db")
cursor = connection.cursor()

def add_user(user_id:int):
    sql = f"INSERT INTO users(id, admin, time, correct_answers) VALUES({user_id}, 0, 0, 0)"
    cursor.execute(sql)
    connection.commit()

def get_user_from_id(id:int):
    sql = f"SELECT * FROM users WHERE id = {id}"
    cursor.execute(sql)
    return cursor.fetchone()

def check_user_register(id:int):
    sql = f"SELECT EXISTS (SELECT 1 FROM users WHERE id = {id})"
    cursor.execute(sql)
    exists = cursor.fetchone()[0]
    return bool(exists)

def set_admin(user_id:int):
    sql = f"UPDATE users SET admin = 1 WHERE id = {user_id}"
    cursor.execute(sql)
    connection.commit()

def check_admin(id:int):
    sql = f"SELECT * FROM users WHERE id = {id} AND admin = 1"
    cursor.execute(sql)
    user = cursor.fetchone()
    if user:
        return True
    else:
        return False
    
def add_question(question:str, answer_1:str, answer_2:str, answer_3:str, answer_4:str, correct_answers:str):
    sql = f"""INSERT INTO questions(question, answer_1, answer_2, answer_3, answer_4, correct_answers) VALUES('{question}', '{answer_1}', '{answer_2}', '{answer_3}', '{answer_4}', '{correct_answers}')"""
    cursor.execute(sql)
    connection.commit()

def delete_questions():
    cursor.execute("DELETE FROM questions")
    cursor.execute("DELETE FROM sqlite_sequence WHERE name = 'questions'")
    connection.commit()

def delete_questions():
    cursor.execute("DELETE FROM questions")
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='sqlite_sequence'")
    if cursor.fetchone():
        cursor.execute("DELETE FROM sqlite_sequence WHERE name = 'questions'")
    connection.commit()


def get_question_from_id(id:int):
    sql = f"SELECT * FROM questions WHERE id = {id}"
    cursor.execute(sql)
    return cursor.fetchone()

def get_questions_count():
    sql = f"SELECT * FROM questions"
    cursor.execute(sql)
    question = cursor.fetchall()
    return len(question)

def get_all_users():
    cursor.execute("SELECT id FROM users")
    return cursor.fetchall()

def result():
    sql = f"SELECT * FROM users WHERE time > 0 and admin = 0 ORDER BY correct_answers DESC, time ASC LIMIT 10"
    cursor.execute(sql)
    question = cursor.fetchall()
    return question

def update_user_results(user_id: int, time: int, correct_answers: int):
    sql = f"UPDATE users SET time = {time}, correct_answers = {correct_answers} WHERE id = {user_id}"
    cursor.execute(sql)
    connection.commit()